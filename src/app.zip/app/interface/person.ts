export interface Person {
    name: string;
    cedula: string;
    proyeccion: string;
    explaboral1: string;
    explaboral2: string;
    titulo3: string;
    titulo4: string;
}