// tslint:disable-next-line: class-name
export class Empleo {
 uid: string;
 titulo: string;
 descripcion: string;
 salario: number;
 image: {}
}
